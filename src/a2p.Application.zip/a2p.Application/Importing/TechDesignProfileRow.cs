using a2p.Application.Importing.BaseModels;

namespace a2p.Application.Importing
{


 public class TechDesignProfileRow : BaseMaterial
 {

  public string ArticleType { get; set; } = string.Empty;
  public string SapaArticle { get; set; } = string.Empty;
  public string ColorDescription { get; set; } = string.Empty;
  public string Info { get; set; } = string.Empty;
 }
}

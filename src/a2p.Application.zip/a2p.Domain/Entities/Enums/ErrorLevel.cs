namespace a2p.Domain.Enums
{
        public enum ErrorLevel
        {
            Warning = 10,
            Error = 20,
            Fatal = 30
        }
    }

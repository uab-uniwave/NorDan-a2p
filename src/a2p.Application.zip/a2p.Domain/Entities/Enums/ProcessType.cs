namespace a2p.Domain.Enums
{
    public enum ProcessType
    {
        None = 0,  //0 
        FileRefresh = 1,  //1
        FileImport = 2,   //2
        LogRefresh = 3,   //3
        LogLoad = 4  //4
    }
}

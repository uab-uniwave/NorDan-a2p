namespace a2p.Domain.Enums
{
    public enum SourceAppType
    {
      Unknown = 0,    
      Sapa = 1,
      TechDesign = 2,
      Schuco = 3
      
            
  }
}

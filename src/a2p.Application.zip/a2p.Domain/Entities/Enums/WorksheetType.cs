namespace a2p.Domain.Enums
{
    public enum WorksheetType
    {
      Unknown = 0,    
      Items = 1,
      Materials = 2,
      Glasses = 3,
      Panels = 4
            
  }
}
